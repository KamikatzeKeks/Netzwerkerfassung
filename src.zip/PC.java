package netzwerkerfassung;

public class PC extends Komponente {

	public PC(String bezeichnung,String typ, String gebaeude, String raum) {
		super(bezeichnung, typ, gebaeude, raum);
		// TODO Auto-generated constructor stub
	}
}
