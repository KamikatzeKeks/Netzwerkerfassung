package netzwerkerfassung;

public class Notebook extends Komponente {

	public Notebook(String bezeichnung,String typ, String gebaeude, String raum) {
		super(bezeichnung, typ, gebaeude, raum);
		// TODO Auto-generated constructor stub
	}

	

}
