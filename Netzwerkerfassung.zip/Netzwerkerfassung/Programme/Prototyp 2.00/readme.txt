Java 8 required 

for compiling SDK 1.8 required 

Github : github.com/KamikatzeKeks/NetzwerkErfassung